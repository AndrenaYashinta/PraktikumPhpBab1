<h3>Kontak Kami</h3>
<p>Jika ada yang ingin mengajukan pertanyaan seputar SMKN 7 Baleendah, bisa dengan cara mengisi form kontak kami dibawah ini dengan nama dan email asli anda</p>

<h4>SMKN 7 Baleendah</h4>
<table border="3" cellpadding="2">
<tr>
	<td>NPSN</td>	
	<td>20229784</td>
</tr>
<tr>
	<td>Nomer Telpon</td>	
	<td>(022) 87799654</td>
</tr>
<tr>
	<td>Email</td>	
	<td>smkn7.baleendah@yahoo.co.id</td>
</tr>
</table>