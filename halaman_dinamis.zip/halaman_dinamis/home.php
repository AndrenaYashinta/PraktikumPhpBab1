<h3>SMKN 7 BALEENDAH</h3>
    <h5>SMKN 7 BALEENDAH didirikan pada tahun 2005. Tepatnya pada kamis, 29 Desember 2005</h5>
     <center><img src="ini.jpg"></center>